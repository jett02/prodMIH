import SmoothScroll from 'smooth-scroll';


new SmoothScroll('[data-scroll]');