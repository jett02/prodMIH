# Cube

Template by WeBuildThemes

## Template Files

You can use CUBE as is out of the box. All ready to use files are in the /dist/ folder.

The webflow workflow can be bypassed all together if you prefer to simply edit the static HTML and CSS files.
But if you are experienced developer and want to speed up development process follow steps bellow.

## Installation

Using node package manager to run the following commands.

```bash
- npm install -> install necessary dependecies
- npm start -> run the dev server locally
- npm run build -> build production files
```

After running npm run build you can check the dist folder for the final html files.
